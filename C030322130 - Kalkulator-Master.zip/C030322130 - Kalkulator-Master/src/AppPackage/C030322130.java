
package AppPackage;

import java.text.DecimalFormat;


public class C030322130 extends javax.swing.JFrame {
String numberString = "";
String dataString = "";
int option;
double number1, number2, result;
    
    public C030322130 () {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        display = new javax.swing.JTextField();
        oneButton = new javax.swing.JButton();
        twoButton = new javax.swing.JButton();
        threeButton = new javax.swing.JButton();
        fourButton = new javax.swing.JButton();
        fiveButton = new javax.swing.JButton();
        sixButton = new javax.swing.JButton();
        sevenButton = new javax.swing.JButton();
        eightButton = new javax.swing.JButton();
        nineButton = new javax.swing.JButton();
        zeroButton = new javax.swing.JButton();
        decButton = new javax.swing.JButton();
        clearButton = new javax.swing.JButton();
        resultButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        subButton = new javax.swing.JButton();
        mulButton = new javax.swing.JButton();
        divButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Simple Calculator");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        display.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        display.setToolTipText("");
        display.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        display.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        display.setEnabled(false);
        getContentPane().add(display, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 16, 242, 47));

        oneButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        oneButton.setText("1");
        oneButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oneButtonActionPerformed(evt);
            }
        });
        getContentPane().add(oneButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 201, 66, 47));

        twoButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        twoButton.setText("2");
        twoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twoButtonActionPerformed(evt);
            }
        });
        getContentPane().add(twoButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 201, 73, 47));

        threeButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        threeButton.setText("3");
        threeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                threeButtonActionPerformed(evt);
            }
        });
        getContentPane().add(threeButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 201, 72, 47));

        fourButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        fourButton.setText("4");
        fourButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fourButtonActionPerformed(evt);
            }
        });
        getContentPane().add(fourButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 136, 66, 43));

        fiveButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        fiveButton.setText("5");
        fiveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fiveButtonActionPerformed(evt);
            }
        });
        getContentPane().add(fiveButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 136, 73, 43));

        sixButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        sixButton.setText("6");
        sixButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sixButtonActionPerformed(evt);
            }
        });
        getContentPane().add(sixButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 137, 72, 42));

        sevenButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        sevenButton.setText("7");
        sevenButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sevenButtonActionPerformed(evt);
            }
        });
        getContentPane().add(sevenButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 82, 66, 43));

        eightButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        eightButton.setText("8");
        eightButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eightButtonActionPerformed(evt);
            }
        });
        getContentPane().add(eightButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 82, 73, 40));

        nineButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        nineButton.setText("9");
        nineButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nineButtonActionPerformed(evt);
            }
        });
        getContentPane().add(nineButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 85, 72, 38));

        zeroButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        zeroButton.setText("0");
        zeroButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                zeroButtonActionPerformed(evt);
            }
        });
        getContentPane().add(zeroButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(22, 269, 66, 43));

        decButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        decButton.setText(".");
        decButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                decButtonActionPerformed(evt);
            }
        });
        getContentPane().add(decButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 266, 73, 43));

        clearButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        clearButton.setText("C");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearButtonActionPerformed(evt);
            }
        });
        getContentPane().add(clearButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 16, 71, 47));

        resultButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        resultButton.setText("=");
        resultButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resultButtonActionPerformed(evt);
            }
        });
        getContentPane().add(resultButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(197, 266, 72, 43));

        addButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        addButton.setText("+");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        getContentPane().add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(287, 82, 66, 43));

        subButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        subButton.setText("-");
        subButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subButtonActionPerformed(evt);
            }
        });
        getContentPane().add(subButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 136, 60, 40));

        mulButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        mulButton.setText("X");
        mulButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mulButtonActionPerformed(evt);
            }
        });
        getContentPane().add(mulButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 196, 60, 50));

        divButton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        divButton.setText("/");
        divButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                divButtonActionPerformed(evt);
            }
        });
        getContentPane().add(divButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 266, 60, 40));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void oneButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oneButtonActionPerformed
numberString += "1";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_oneButtonActionPerformed

    private void twoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twoButtonActionPerformed
numberString += "2";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_twoButtonActionPerformed

    private void threeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_threeButtonActionPerformed
numberString += "3";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_threeButtonActionPerformed

    private void fourButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fourButtonActionPerformed
numberString += "4";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_fourButtonActionPerformed

    private void fiveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fiveButtonActionPerformed
numberString += "5";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_fiveButtonActionPerformed

    private void sixButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sixButtonActionPerformed
numberString += "6";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_sixButtonActionPerformed

    private void sevenButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sevenButtonActionPerformed
numberString += "7";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_sevenButtonActionPerformed

    private void eightButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eightButtonActionPerformed
numberString += "8";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_eightButtonActionPerformed

    private void nineButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nineButtonActionPerformed
numberString += "9";
display.setText(numberString);
// TODO add your handling code here:
    }//GEN-LAST:event_nineButtonActionPerformed

    private void zeroButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_zeroButtonActionPerformed
numberString += "0";
display.setText(numberString);

    }//GEN-LAST:event_zeroButtonActionPerformed

    private void decButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_decButtonActionPerformed
numberString += ".";
display.setText(numberString);

    }//GEN-LAST:event_decButtonActionPerformed

    private void clearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearButtonActionPerformed
numberString = "";
number1 = number2 = result = 0.0;
display.setText(null);

    }//GEN-LAST:event_clearButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
number1 = Double.parseDouble(numberString);
numberString = "";
display.setText("+");
option = 1;
    }//GEN-LAST:event_addButtonActionPerformed

    private void subButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subButtonActionPerformed
number1 = Double.parseDouble(numberString);
numberString = "";
display.setText("-");
option = 2;
    }//GEN-LAST:event_subButtonActionPerformed

    private void mulButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mulButtonActionPerformed
number1 = Double.parseDouble(numberString);
numberString = "";
display.setText("X");
option = 3;
    }//GEN-LAST:event_mulButtonActionPerformed

    private void divButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_divButtonActionPerformed
number1 = Double.parseDouble(numberString);
numberString = "";
display.setText("/");
option = 4;// TODO add your handling code here:
    }//GEN-LAST:event_divButtonActionPerformed

    private void resultButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resultButtonActionPerformed
switch(option)
{
    case 1:
        number2 = Double.parseDouble(numberString);
        result = number1 + number2;
        number1 = result;
        display.setText(Double.toString(result));
        numberString = display.getText();
        break;
    case 2:
        number2 = Double.parseDouble(numberString);
        result = number1 - number2;
        number1 = result;
        display.setText(Double.toString(result));
        numberString = display.getText();
        break;
    case 3:
        number2 = Double.parseDouble(numberString);
        result = number1 * number2;
        number1 = result;
        display.setText(Double.toString(result));
        numberString = display.getText();
        break;
    case 4:
        number2 = Double.parseDouble(numberString);
        result = number1 / number2;
        display.setText(Double.toString(result));
        numberString = display.getText();
        break;
    default:
        break;
}       DecimalFormat decimalFormat = new DecimalFormat("0.#");
        display.setText(decimalFormat.format(result));
        numberString = display.getText();
    }//GEN-LAST:event_resultButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new C030322130 ().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JButton clearButton;
    private javax.swing.JButton decButton;
    private javax.swing.JTextField display;
    private javax.swing.JButton divButton;
    private javax.swing.JButton eightButton;
    private javax.swing.JButton fiveButton;
    private javax.swing.JButton fourButton;
    private javax.swing.JButton mulButton;
    private javax.swing.JButton nineButton;
    private javax.swing.JButton oneButton;
    private javax.swing.JButton resultButton;
    private javax.swing.JButton sevenButton;
    private javax.swing.JButton sixButton;
    private javax.swing.JButton subButton;
    private javax.swing.JButton threeButton;
    private javax.swing.JButton twoButton;
    private javax.swing.JButton zeroButton;
    // End of variables declaration//GEN-END:variables
}
